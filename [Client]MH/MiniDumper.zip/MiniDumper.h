





//////////////////////////////////////////////////////////////////////////////
/// \file MiniDumper.h

/// \author excel96
/// \date 2003.11.18
//////////////////////////////////////////////////////////////////////////////

#ifndef __MINIDUMPER_H__
#define __MINIDUMPER_H__


#ifndef __NONCOPYABLE_H__
#include "Noncopyable.h"
#endif


class MiniDumper : private Noncopyable
{
public:
	enum DumpLevel
	{
		DUMP_LEVEL_0, 
		DUMP_LEVEL_1, 
		DUMP_LEVEL_2  
	};


private:
	static DumpLevel s_DumpLevel;            
	static bool s_bAddTimeStamp;
	static TCHAR s_szAppName[_MAX_PATH];
	static TCHAR s_szFaultReason[2048];


public:
	MiniDumper(DumpLevel DL, bool bAddTimestamp=true);
	~MiniDumper();


private:
	static LONG WINAPI TopLevelFilter(struct _EXCEPTION_POINTERS* pExPtrs);
	static LPCTSTR GetFaultReason(struct _EXCEPTION_POINTERS* pExPtrs);
};

#endif //__MINIDUMPER_H__


